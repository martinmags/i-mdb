zekria sidiqi
a12330033
martin magsombol
a14692975
NOTE: in the login-signup form we have a two seperated containers with forms in each.
one for login and one for signup. we used the same name and id for each (meaning
non-unique ids). however this is one of the if you know the rules you can break the rules
situation where we did to have the DataForm object nicely collect our form data and at the
same time we were highly specific to our degrees of querySelectors when getting these fields
another note: we get a "Bad value 'dialog' for attribute 'method' on element 'form'". but this
is also one of those if we know the rules we can break the rules circumstances
EXTRA CREDITS:
(1) - flashier interface
(2) - mobile interface
(3) - responsive design
